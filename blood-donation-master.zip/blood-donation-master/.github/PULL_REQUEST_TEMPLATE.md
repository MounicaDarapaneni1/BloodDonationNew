# Fill out the following while publishing a new pull request.

* **What kind of change does this PR introduce?** (Bug fix, feature, docs update, ...)
Just user details layout.


* **What is the current behavior?** (You can also link to an open issue here)
No behaviour change.


* **What is the new behavior (if this is a feature change)?**
No behaviour change.


* **Does this PR introduce a breaking change?** (What changes might users need to make in their application due to this PR?)
No


* **Other information**:
